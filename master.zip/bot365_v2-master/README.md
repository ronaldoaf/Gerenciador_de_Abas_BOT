# Gerenciador_de_Abas_BOT
Exemplo de uma extensão para o Chrome que abre determinas abas e verifica se elas se mantem ativas
